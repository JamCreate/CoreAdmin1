# Modrinth release checklist

Project type: Plugin
Name: CoreAdmin
Slug: coreadmin
Version: 1.0.0
Loader: Paper
Environment: Server-side
Minecraft versions: select only versions actually tested.
Release channel: Release

Primary file:
`build/libs/CoreAdmin-1.0.0.jar`

Do not upload the source ZIP as the primary plugin file.

Suggested categories/tags:
- administration
- performance
- moderation
- paper

Suggested short description:
"Lightweight all-in-one administration, moderation, maintenance, and performance tools for Paper servers."

Changelog:
See CHANGELOG.md.
