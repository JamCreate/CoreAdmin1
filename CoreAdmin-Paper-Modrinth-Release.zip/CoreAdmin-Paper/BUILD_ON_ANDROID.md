# Build on Android

The easiest no-PC route is GitHub Actions:

1. Create a GitHub repository.
2. Upload this project.
3. The included `.github/workflows/build.yml` runs automatically when you push a tag such as `v1.0.0`.
4. Open GitHub -> Actions -> Build CoreAdmin.
5. Download the `CoreAdmin` artifact from the successful run.
6. The artifact contains the shaded Paper JAR.

You can also build locally with Gradle on Android if you already have a Java 21 + Gradle environment.
