# CoreAdmin

CoreAdmin is an all-in-one administration, moderation, maintenance, and performance utility plugin for Paper.

## Requirements
- Paper 1.21.x
- Java 21

## Installation
1. Download the `CoreAdmin-1.0.0.jar` release.
2. Put it in your server's `plugins/` directory.
3. Start the server.
4. Configure `plugins/CoreAdmin/config.yml`.
5. Restart the server or use `/coreadmin reload`.

## Commands
- `/coreadmin reload`
- `/maintenance <on|off>`
- `/vanish [player]`
- `/ban <player> [reason]`
- `/mute <player> [time] [reason]`
- `/clearentities`
- `/tps`
- `/mem`
- `/staffchat <message>`

## Permissions
See `plugin.yml` for the complete permission list.

## Notes
CoreAdmin is server-side only. It uses Paper's Adventure/MiniMessage APIs and asynchronous database operations.

## License
MIT
