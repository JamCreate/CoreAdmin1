package com.coreadmin.config;

import com.coreadmin.CoreAdmin;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;

public final class ConfigManager {
    private final CoreAdmin plugin;
    private FileConfiguration messages;
    private File messagesFile;
    public ConfigManager(CoreAdmin plugin) { this.plugin = plugin; }
    public void load() {
        plugin.saveDefaultConfig();
        messagesFile = new File(plugin.getDataFolder(), "messages.yml");
        if (!messagesFile.exists()) plugin.saveResource("messages.yml", false);
        messages = YamlConfiguration.loadConfiguration(messagesFile);
    }
    public void reload() { plugin.reloadConfig(); messages = YamlConfiguration.loadConfiguration(messagesFile); }
    public FileConfiguration main() { return plugin.getConfig(); }
    public FileConfiguration messages() { return messages; }
}
