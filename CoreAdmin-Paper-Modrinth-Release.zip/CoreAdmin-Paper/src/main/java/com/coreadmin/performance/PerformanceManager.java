package com.coreadmin.performance;

import com.coreadmin.CoreAdmin;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.ExperienceOrb;
import java.util.concurrent.atomic.AtomicBoolean;

public final class PerformanceManager {
    private final CoreAdmin plugin;
    private final AtomicBoolean running = new AtomicBoolean();
    public PerformanceManager(CoreAdmin plugin) { this.plugin=plugin; }
    public void start() {
        if (!plugin.config().main().getBoolean("modules.performance", true)) return;
        running.set(true);
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!running.get()) return;
            double tps = Bukkit.getTPS()[0];
            int distance = tps < plugin.config().main().getDouble("performance.low-tps",18.5)
                    ? plugin.config().main().getInt("performance.low-tps-view-distance",5)
                    : plugin.config().main().getInt("performance.normal-view-distance",8);
            for (World world : Bukkit.getWorlds()) {
                if (world.getViewDistance() != distance) world.setViewDistance(distance);
            }
        }, 20L, 100L);
    }
    public void stop() { running.set(false); }
    public int clearEntities() {
        int count=0;
        for(World world:Bukkit.getWorlds()) for(Entity e:world.getEntities()) {
            if (e instanceof Item || e instanceof ExperienceOrb) { e.remove(); count++; }
        }
        return count;
    }
}
