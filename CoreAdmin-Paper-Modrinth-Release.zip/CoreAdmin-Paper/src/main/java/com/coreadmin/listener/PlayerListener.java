package com.coreadmin.listener;

import com.coreadmin.CoreAdmin;
import net.kyori.adventure.text.minimessage.MiniMessage;
import io.papermc.paper.event.player.AsyncChatEvent;
import org.bukkit.Bukkit;
import org.bukkit.event.*;
import org.bukkit.event.player.*;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PlayerListener implements Listener {
    private final CoreAdmin plugin;
    private final Map<UUID, Long> lastChat = new ConcurrentHashMap<>();

    public PlayerListener(CoreAdmin plugin) { this.plugin = plugin; }

    @EventHandler
    public void onLogin(PlayerLoginEvent e) {
        if (plugin.config().main().getBoolean("maintenance.enabled", false)
                && !e.getPlayer().hasPermission("coreadmin.maintenance.bypass")) {
            e.disallow(PlayerLoginEvent.Result.KICK_OTHER,
                MiniMessage.miniMessage().deserialize(plugin.config().main()
                    .getString("maintenance.kick-message", "<red>Server is under maintenance.</red>")));
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        plugin.database().isMuted(id.toString()).thenAccept(muted -> {
            if (muted) plugin.getLogger().fine("Muted player joined: " + e.getPlayer().getName());
        });
        Bukkit.getScheduler().runTask(plugin, () -> {
            for (org.bukkit.entity.Player staff : Bukkit.getOnlinePlayers()) {
                if (!staff.hasPermission("coreadmin.staff.vanish")) {
                    for (UUID vanished : plugin.commands().vanished())
                        Bukkit.getPlayer(vanished);
                }
            }
        });
    }

    @EventHandler
    public void onChat(AsyncChatEvent e) {
        long now = System.currentTimeMillis();
        long cd = plugin.config().main().getLong("chat.spam-cooldown-ms", 1000L);
        Long old = lastChat.put(e.getPlayer().getUniqueId(), now);
        if (old != null && now - old < cd) {
            e.setCancelled(true);
            e.getPlayer().sendMessage(MiniMessage.miniMessage().deserialize("<red>Please slow down.</red>"));
            return;
        }

        plugin.database().isMuted(e.getPlayer().getUniqueId().toString()).thenAccept(muted -> {
            if (muted) {
                e.setCancelled(true);
                Bukkit.getScheduler().runTask(plugin, () ->
                    e.getPlayer().sendMessage(MiniMessage.miniMessage().deserialize(
                        plugin.config().messages().getString("muted", "<red>You are muted.</red>"))));
            }
        });
    }
}
