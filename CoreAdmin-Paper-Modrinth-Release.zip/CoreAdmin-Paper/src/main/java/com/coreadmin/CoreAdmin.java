package com.coreadmin;

import com.coreadmin.command.AdminCommands;
import com.coreadmin.config.ConfigManager;
import com.coreadmin.database.DatabaseManager;
import com.coreadmin.listener.PlayerListener;
import com.coreadmin.performance.PerformanceManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class CoreAdmin extends JavaPlugin {
    private ConfigManager configManager;
    private DatabaseManager databaseManager;
    private PerformanceManager performanceManager;
    private AdminCommands commands;

    @Override public void onEnable() {
        configManager = new ConfigManager(this);
        configManager.load();
        databaseManager = new DatabaseManager(this);
        databaseManager.start();
        performanceManager = new PerformanceManager(this);
        performanceManager.start();
        commands = new AdminCommands(this);
        getCommand("coreadmin").setExecutor(commands);
        getCommand("maintenance").setExecutor(commands);
        getCommand("vanish").setExecutor(commands);
        getCommand("ban").setExecutor(commands);
        getCommand("mute").setExecutor(commands);
        getCommand("clearentities").setExecutor(commands);
        getCommand("tps").setExecutor(commands);
        getCommand("mem").setExecutor(commands);
        getCommand("staffchat").setExecutor(commands);
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        getLogger().info("CoreAdmin enabled for PaperMC.");
    }

    @Override public void onDisable() {
        if (performanceManager != null) performanceManager.stop();
        if (databaseManager != null) databaseManager.close();
    }

    public ConfigManager config() { return configManager; }
    public DatabaseManager database() { return databaseManager; }
    public PerformanceManager performance() { return performanceManager; }
    public AdminCommands commands() { return commands; }
}
