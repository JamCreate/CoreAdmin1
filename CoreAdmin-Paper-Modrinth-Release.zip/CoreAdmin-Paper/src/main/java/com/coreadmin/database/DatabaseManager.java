package com.coreadmin.database;

import com.coreadmin.CoreAdmin;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.function.Function;
import java.util.concurrent.CompletableFuture;

public final class DatabaseManager {
    private final CoreAdmin plugin;
    private HikariDataSource dataSource;
    public DatabaseManager(CoreAdmin plugin) { this.plugin = plugin; }
    public void start() {
        try {
            File dir = plugin.getDataFolder(); if (!dir.exists()) dir.mkdirs();
            HikariConfig cfg = new HikariConfig();
            String type = plugin.config().main().getString("database.type", "sqlite");
            if ("mysql".equalsIgnoreCase(type)) {
                cfg.setJdbcUrl(plugin.config().main().getString("database.mysql.jdbc-url"));
                cfg.setUsername(plugin.config().main().getString("database.mysql.username"));
                cfg.setPassword(plugin.config().main().getString("database.mysql.password"));
            } else {
                File db = new File(plugin.getDataFolder(), "coreadmin.db");
                cfg.setJdbcUrl("jdbc:sqlite:" + db.getAbsolutePath());
            }
            cfg.setMaximumPoolSize(plugin.config().main().getInt("database.mysql.maximum-pool-size", 5));
            cfg.setPoolName("CoreAdmin-Hikari");
            dataSource = new HikariDataSource(cfg);
            update("CREATE TABLE IF NOT EXISTS punishments (id INTEGER PRIMARY KEY, uuid VARCHAR(36), type VARCHAR(16), reason TEXT, expires BIGINT, created BIGINT)");
        } catch (Exception e) { plugin.getLogger().severe("Database startup failed: " + e.getMessage()); }
    }
    public CompletableFuture<Void> update(String sql, Object... args) {
        if (dataSource == null) return CompletableFuture.failedFuture(new IllegalStateException("Database is not initialized."));
        return CompletableFuture.runAsync(() -> { try (Connection c=dataSource.getConnection(); var ps=c.prepareStatement(sql)) { for(int i=0;i<args.length;i++) ps.setObject(i+1,args[i]); ps.executeUpdate(); } catch(SQLException e){ plugin.getLogger().warning(e.getMessage()); } });
    }
    public CompletableFuture<Boolean> isMuted(String uuid) {
        return CompletableFuture.supplyAsync(() -> {
            if (dataSource == null) return false;
            String sql = "SELECT expires FROM punishments WHERE uuid=? AND type='MUTE' ORDER BY created DESC LIMIT 1";
            try (Connection c=dataSource.getConnection(); var ps=c.prepareStatement(sql)) {
                ps.setString(1, uuid);
                try (ResultSet rs=ps.executeQuery()) {
                    if (!rs.next()) return false;
                    long expires = rs.getLong(1);
                    return expires == 0L || expires > System.currentTimeMillis();
                }
            } catch (SQLException e) {
                plugin.getLogger().warning("Mute lookup failed: " + e.getMessage());
                return false;
            }
        });
    }

    public void close() { if (dataSource != null) dataSource.close(); }
}
