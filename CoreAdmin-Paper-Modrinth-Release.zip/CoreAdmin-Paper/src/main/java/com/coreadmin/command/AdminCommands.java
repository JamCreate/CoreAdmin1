package com.coreadmin.command;

import com.coreadmin.CoreAdmin;
import io.papermc.paper.ban.BanListType;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class AdminCommands implements CommandExecutor {
    private final CoreAdmin plugin;
    private final MiniMessage mm = MiniMessage.miniMessage();
    private final Set<UUID> vanished = ConcurrentHashMap.newKeySet();

    public AdminCommands(CoreAdmin plugin) { this.plugin = plugin; }

    public Set<UUID> vanished() { return vanished; }

    private boolean perm(CommandSender s, String permission) {
        if (!s.hasPermission(permission)) {
            msg(s, "no-permission");
            return false;
        }
        return true;
    }

    public void msg(CommandSender s, String key) {
        s.sendMessage(mm.deserialize(plugin.config().messages().getString(key, "<red>Missing message.</red>")));
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        switch (c.getName().toLowerCase(Locale.ROOT)) {
            case "coreadmin" -> {
                if (!perm(s, "coreadmin.admin.reload")) return true;
                if (a.length == 1 && a[0].equalsIgnoreCase("reload")) {
                    plugin.config().reload();
                    msg(s, "reloaded");
                } else s.sendMessage(mm.deserialize("<yellow>Usage: /coreadmin reload</yellow>"));
            }
            case "maintenance" -> {
                if (!perm(s, "coreadmin.admin.maintenance")) return true;
                if (a.length != 1 || !(a[0].equalsIgnoreCase("on") || a[0].equalsIgnoreCase("off"))) {
                    s.sendMessage(mm.deserialize("<yellow>Usage: /maintenance <on|off></yellow>"));
                    return true;
                }
                boolean on = a[0].equalsIgnoreCase("on");
                plugin.config().main().set("maintenance.enabled", on);
                plugin.saveConfig();
                msg(s, on ? "maintenance-on" : "maintenance-off");
            }
            case "vanish" -> {
                if (!perm(s, "coreadmin.staff.vanish")) return true;
                Player p = a.length > 0 ? Bukkit.getPlayerExact(a[0]) : (s instanceof Player ? (Player)s : null);
                if (p == null) { msg(s, "player-not-found"); return true; }
                toggleVanish(p);
            }
            case "ban" -> {
                if (!perm(s, "coreadmin.staff.ban")) return true;
                if (a.length < 1) { s.sendMessage(mm.deserialize("<yellow>Usage: /ban <player> [reason]</yellow>")); return true; }
                OfflinePlayer p = Bukkit.getOfflinePlayer(a[0]);
                String reason = a.length > 1 ? String.join(" ", Arrays.copyOfRange(a, 1, a.length)) : "Banned by staff";
                Bukkit.getBanList(BanListType.PROFILE).addBan(p.getPlayerProfile(), reason, null, s.getName());
                Player online = p.getPlayer();
                if (online != null) online.kick(mm.deserialize("<red>Banned:</red> <white>" + escape(reason) + "</white>"));
                msg(s, "ban-success");
            }
            case "mute" -> {
                if (!perm(s, "coreadmin.staff.mute")) return true;
                if (a.length < 1) { s.sendMessage(mm.deserialize("<yellow>Usage: /mute <player> [time] [reason]</yellow>")); return true; }
                Player p = Bukkit.getPlayerExact(a[0]);
                if (p == null) { msg(s, "player-not-found"); return true; }
                String duration = a.length > 1 ? a[1] : "perm";
                String reason = a.length > 2 ? String.join(" ", Arrays.copyOfRange(a, 2, a.length)) : "Muted by staff";
                long expires = parseTime(duration);
                plugin.database().update(
                    "INSERT INTO punishments(uuid,type,reason,expires,created) VALUES(?,?,?,?,?)",
                    p.getUniqueId().toString(), "MUTE", reason, expires, System.currentTimeMillis()
                );
                msg(s, "mute-success");
                msg(p, "muted");
            }
            case "clearentities" -> {
                if (!perm(s, "coreadmin.admin.clearlag")) return true;
                int count = plugin.performance().clearEntities();
                s.sendMessage(mm.deserialize(plugin.config().messages()
                    .getString("entity-clear", "<green>Removed <count> entities.</green>")
                    .replace("<count>", String.valueOf(count))));
            }
            case "tps" -> {
                if (!perm(s, "coreadmin.staff.performance")) return true;
                s.sendMessage(mm.deserialize("<aqua>TPS:</aqua> <white>" + String.format(Locale.US, "%.2f", Bukkit.getTPS()[0]) + "</white>"));
            }
            case "mem" -> {
                if (!perm(s, "coreadmin.staff.performance")) return true;
                Runtime r = Runtime.getRuntime();
                long used = (r.totalMemory() - r.freeMemory()) / 1048576;
                long max = r.maxMemory() / 1048576;
                s.sendMessage(mm.deserialize("<aqua>Memory:</aqua> <white>" + used + "MB / " + max + "MB</white>"));
            }
            case "staffchat" -> {
                if (!perm(s, "coreadmin.staff.chat")) return true;
                if (a.length == 0) return true;
                String m = String.join(" ", a);
                String format = plugin.config().messages().getString("staffchat", "<gray>[Staff] <player>: <message></gray>");
                for (Player p : Bukkit.getOnlinePlayers())
                    if (p.hasPermission("coreadmin.staff.chat"))
                        p.sendMessage(mm.deserialize(format.replace("<player>", escape(s.getName())).replace("<message>", escape(m))));
                if (!(s instanceof Player)) s.sendMessage(mm.deserialize(format.replace("<player>", escape(s.getName())).replace("<message>", escape(m))));
            }
        }
        return true;
    }

    public void toggleVanish(Player p) {
        if (vanished.add(p.getUniqueId())) {
            for (Player x : Bukkit.getOnlinePlayers())
                if (!x.hasPermission("coreadmin.staff.vanish")) x.hidePlayer(plugin, p);
            msg(p, "vanish-on");
        } else {
            vanished.remove(p.getUniqueId());
            for (Player x : Bukkit.getOnlinePlayers()) x.showPlayer(plugin, p);
            msg(p, "vanish-off");
        }
    }

    private long parseTime(String s) {
        if (s.equalsIgnoreCase("perm")) return 0L;
        try {
            char u = Character.toLowerCase(s.charAt(s.length() - 1));
            long n = Long.parseLong(s.substring(0, s.length() - 1));
            long multiplier = switch (u) {
                case 's' -> 1000L;
                case 'm' -> 60_000L;
                case 'h' -> 3_600_000L;
                case 'd' -> 86_400_000L;
                default -> 0L;
            };
            return multiplier == 0 ? 0L : System.currentTimeMillis() + n * multiplier;
        } catch (Exception ignored) {
            return 0L;
        }
    }

    private String escape(String s) {
        return s.replace("<", "&lt;").replace(">", "&gt;");
    }
}
