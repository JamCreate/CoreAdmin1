# CoreAdmin 1.0.0

Initial Paper release.

- Paper 1.21.x / Java 21 target
- Administration commands
- Maintenance mode
- Vanish
- Ban and mute storage
- Async SQLite/MySQL database layer
- TPS and memory tools
- Entity cleanup
- Chat cooldown and mute enforcement
- Configurable MiniMessage messages
- Shaded runtime dependencies
